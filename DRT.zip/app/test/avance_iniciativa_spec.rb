describe "AvanceIniciativa" do
  #this test always fails, you really should have tests!

  it "should have tests" do
    true.should == false
  end
end