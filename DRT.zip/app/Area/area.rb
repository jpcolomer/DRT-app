# The model has already been created by the framework, and extends Rhom::RhomObject
# You can add more methods here
require 'helpers/avance_helper'
class Area
  include Rhom::PropertyBag
  include AvanceHelper
  # Uncomment the following line to enable sync with Area.
  # enable :sync

  #add model specifc code here
   
  
  
end