function doSync() {
	$.get("/system/syncdb",function(data) {});
	return false;
}
